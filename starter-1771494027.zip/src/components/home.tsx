import Navbar from "@/components/portfolio/Navbar";
import HeroSection from "@/components/portfolio/HeroSection";
import AboutSection from "@/components/portfolio/AboutSection";
import CertificationSection from "@/components/portfolio/CertificationSection";
import ProjectSection from "@/components/portfolio/ProjectSection";
import SkillsSection from "@/components/portfolio/SkillsSection";
import ContactSection from "@/components/portfolio/ContactSection";
import Footer from "@/components/portfolio/Footer";

function Home() {
  return (
    <div className="min-h-screen bg-cream noise-bg">
      <Navbar />
      <main className="relative z-10">
        <HeroSection />
        <AboutSection />
        <CertificationSection />
        <ProjectSection />
        <SkillsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default Home;
