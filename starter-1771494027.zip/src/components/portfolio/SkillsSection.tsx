import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { BarChart3, Target, PieChart, Users } from "lucide-react";

const skills = [
  {
    name: "Business Analysis",
    icon: BarChart3,
    level: 90,
    description: "Strategic planning, requirements gathering, process optimization, and data-driven decision making",
    tools: ["Excel", "Power BI", "SWOT Analysis", "Business Modeling"],
    color: "sienna",
  },
  {
    name: "Marketing",
    icon: Target,
    level: 85,
    description: "Market research, consumer behavior, brand strategy, campaign management, and performance tracking",
    tools: ["Google Analytics", "SEO Tools", "Social Media", "Content Strategy"],
    color: "slate_blue",
  },
  {
    name: "Finance",
    icon: PieChart,
    level: 80,
    description: "Financial modeling, budgeting, risk assessment, investment analysis, and fiscal reporting",
    tools: ["Financial Modeling", "Budgeting", "Risk Analysis", "Valuation"],
    color: "sienna",
  },
  {
    name: "Human Resources",
    icon: Users,
    level: 75,
    description: "Talent management, organizational development, performance analytics, and workforce planning",
    tools: ["Talent Acquisition", "HR Analytics", "Performance Mgmt", "Employee Relations"],
    color: "slate_blue",
  },
];

const SkillsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="skills" className="py-24 md:py-32" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.4, 0.0, 0.2, 1] }}
          className="mb-12"
        >
          <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
            Core Competencies
          </span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-charcoal mt-3">
            Skills Matrix
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            const isWarm = skill.color === "sienna";

            return (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{
                  duration: 0.6,
                  delay: 0.1 + index * 0.1,
                  ease: [0.4, 0.0, 0.2, 1],
                }}
                className="group bg-white rounded-xl border border-warm-gray shadow-card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isWarm ? "bg-sienna/10" : "bg-slate_blue/10"
                    }`}
                  >
                    <Icon
                      className={`w-6 h-6 ${
                        isWarm ? "text-sienna" : "text-slate_blue"
                      }`}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-heading text-lg font-semibold text-charcoal">
                        {skill.name}
                      </h3>
                      <span
                        className={`font-mono-custom text-sm font-medium ${
                          isWarm ? "text-sienna" : "text-slate_blue"
                        }`}
                      >
                        {skill.level}%
                      </span>
                    </div>

                    {/* Progress bar */}
                    <div className="w-full h-1.5 bg-warm-gray/50 rounded-full overflow-hidden mb-3">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={isInView ? { width: `${skill.level}%` } : {}}
                        transition={{
                          duration: 1,
                          delay: 0.3 + index * 0.1,
                          ease: [0.4, 0.0, 0.2, 1],
                        }}
                        className={`h-full rounded-full ${
                          isWarm
                            ? "bg-gradient-to-r from-sienna to-sienna-light"
                            : "bg-gradient-to-r from-slate_blue to-slate_blue/70"
                        }`}
                      />
                    </div>
                  </div>
                </div>

                <p className="font-body text-sm text-charcoal/60 mb-4 leading-relaxed">
                  {skill.description}
                </p>

                {/* Tools/Skills */}
                <div className="flex flex-wrap gap-1.5">
                  {skill.tools.map((tool) => (
                    <span
                      key={tool}
                      className={`px-2.5 py-1 text-xs font-heading font-medium rounded-md border transition-transform duration-200 hover:scale-[1.02] cursor-default ${
                        isWarm
                          ? "bg-sienna/5 text-sienna/80 border-sienna/10"
                          : "bg-slate_blue/5 text-slate_blue/80 border-slate_blue/10"
                      }`}
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
