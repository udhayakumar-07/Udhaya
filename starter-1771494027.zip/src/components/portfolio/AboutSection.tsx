import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { GraduationCap, MapPin, Calendar } from "lucide-react";

const specializations = [
  { label: "Business Analysis", color: "bg-sienna/10 text-sienna border-sienna/20" },
  { label: "Marketing", color: "bg-slate_blue/10 text-slate_blue border-slate_blue/20" },
  { label: "Finance", color: "bg-sienna/10 text-sienna border-sienna/20" },
  { label: "Human Resources", color: "bg-slate_blue/10 text-slate_blue border-slate_blue/20" },
];

const tooltipContent: Record<string, string> = {
  "Business Analysis": "Strategic planning, data-driven decision making, process optimization, and requirements gathering",
  "Marketing": "Market research, consumer behavior analysis, brand strategy, and campaign management",
  "Finance": "Financial modeling, budgeting, risk assessment, and investment analysis",
  "Human Resources": "Talent management, organizational development, performance analytics, and workforce planning",
};

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-24 md:py-32" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.4, 0.0, 0.2, 1] }}
          className="mb-12"
        >
          <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
            About Me
          </span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-charcoal mt-3">
            Education & Background
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main About Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.4, 0.0, 0.2, 1] }}
            className="lg:col-span-2 bg-white rounded-xl border border-warm-gray shadow-card p-8 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 rounded-lg bg-sienna/10 flex items-center justify-center flex-shrink-0">
                <GraduationCap className="w-6 h-6 text-sienna" />
              </div>
              <div>
                <h3 className="font-heading text-xl font-semibold text-charcoal">
                  Master of Business Administration
                </h3>
                <p className="font-body text-charcoal/60 mt-1">
                  A comprehensive MBA program focused on developing analytical thinking, strategic leadership, and cross-functional business expertise.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 mb-6 text-charcoal/60">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4" />
                <span className="font-body text-sm">SRM University</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span className="font-mono-custom text-sm">2024 – 2025</span>
              </div>
            </div>

            {/* Specialization Tags */}
            <div>
              <p className="font-heading text-sm font-semibold text-charcoal/80 mb-3">
                Specializations
              </p>
              <div className="flex flex-wrap gap-2">
                {specializations.map((spec, index) => (
                  <motion.div
                    key={spec.label}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{
                      duration: 0.4,
                      delay: 0.3 + index * 0.08,
                      ease: [0.4, 0.0, 0.2, 1],
                    }}
                    className="group relative"
                  >
                    <span
                      className={`inline-flex px-4 py-2 rounded-lg border text-sm font-heading font-medium transition-transform duration-200 cursor-default hover:scale-[1.02] ${spec.color}`}
                    >
                      {spec.label}
                    </span>
                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-charcoal text-cream text-xs font-body rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-20 shadow-lg pointer-events-none">
                      {tooltipContent[spec.label]}
                      <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 w-2 h-2 bg-charcoal rotate-45" />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Side Info Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2, ease: [0.4, 0.0, 0.2, 1] }}
            className="bg-white rounded-xl border border-warm-gray shadow-card p-8 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
          >
            <div className="h-full flex flex-col justify-between">
              <div>
                <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-sienna/20 to-slate_blue/20 flex items-center justify-center mb-6">
                  <span className="font-display text-3xl font-bold text-charcoal">U</span>
                </div>
                <h3 className="font-heading text-lg font-semibold text-charcoal mb-2">
                  Quick Facts
                </h3>
              </div>
              <div className="space-y-4 mt-4">
                <div className="flex items-center justify-between py-2 border-b border-warm-gray/60">
                  <span className="font-body text-sm text-charcoal/60">Degree</span>
                  <span className="font-mono-custom text-sm text-charcoal font-medium">MBA</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-warm-gray/60">
                  <span className="font-body text-sm text-charcoal/60">University</span>
                  <span className="font-mono-custom text-sm text-charcoal font-medium">SRM</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-warm-gray/60">
                  <span className="font-body text-sm text-charcoal/60">Year</span>
                  <span className="font-mono-custom text-sm text-charcoal font-medium">2024–25</span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="font-body text-sm text-charcoal/60">Focus</span>
                  <span className="font-mono-custom text-sm text-sienna font-medium">Analytics</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
