import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Animated gradient mesh background */}
      <div className="absolute inset-0 opacity-30">
        <div
          className="absolute inset-0 animate-gradient-shift"
          style={{
            background:
              "radial-gradient(ellipse at 20% 50%, rgba(193, 127, 74, 0.15) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(58, 90, 107, 0.1) 0%, transparent 50%), radial-gradient(ellipse at 50% 80%, rgba(193, 127, 74, 0.08) 0%, transparent 50%)",
            backgroundSize: "200% 200%",
          }}
        />
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 lg:px-16 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
          {/* Left: Text content (60%) */}
          <div className="lg:col-span-3 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                ease: [0.4, 0.0, 0.2, 1],
              }}
            >
              <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
                MBA Graduate · Business Analyst
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 0.1,
                ease: [0.4, 0.0, 0.2, 1],
              }}
              className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-charcoal leading-[1.1]"
            >
              Udhayakumar
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 0.2,
                ease: [0.4, 0.0, 0.2, 1],
              }}
              className="font-body text-xl md:text-2xl text-charcoal/70 max-w-xl leading-relaxed"
            >
              Transforming complex business data into actionable insights.
              Specializing in{" "}
              <span className="text-sienna font-medium">
                Business Analysis
              </span>
              ,{" "}
              <span className="text-slate_blue font-medium">
                Digital Marketing
              </span>
              , and{" "}
              <span className="text-sienna font-medium">
                Financial Strategy
              </span>
              .
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 0.3,
                ease: [0.4, 0.0, 0.2, 1],
              }}
              className="flex flex-wrap gap-3 pt-2"
            >
              <a
                href="#project"
                className="inline-flex items-center gap-2 px-6 py-3 bg-sienna text-cream font-heading font-semibold text-sm rounded-lg hover:bg-sienna/90 transition-all duration-200 hover:-translate-y-0.5 shadow-card hover:shadow-card-hover"
              >
                View Featured Project
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 border border-charcoal/20 text-charcoal font-heading font-semibold text-sm rounded-lg hover:border-sienna hover:text-sienna transition-all duration-200 hover:-translate-y-0.5"
              >
                Get in Touch
              </a>
            </motion.div>
          </div>

          {/* Right: Visual element (40%) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              duration: 1,
              delay: 0.4,
              ease: [0.4, 0.0, 0.2, 1],
            }}
            className="lg:col-span-2 hidden lg:flex justify-center"
          >
            <div className="relative w-72 h-72">
              {/* Decorative rings */}
              <div className="absolute inset-0 rounded-full border-2 border-sienna/20 animate-pulse" />
              <div className="absolute inset-4 rounded-full border border-slate_blue/15" />
              <div className="absolute inset-8 rounded-full bg-gradient-to-br from-sienna/10 to-slate_blue/10" />
              {/* Center content */}
              <div className="absolute inset-12 rounded-full bg-cream flex items-center justify-center shadow-card border border-warm-gray">
                <div className="text-center">
                  <span className="font-display text-4xl font-bold text-sienna">
                    U
                  </span>
                  <p className="font-mono-custom text-[10px] text-charcoal/50 mt-1">
                    2024–2025
                  </p>
                </div>
              </div>
              {/* Floating badges */}
              <motion.div
                animate={{ y: [-5, 5, -5] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-2 right-8 bg-white rounded-lg shadow-card px-3 py-1.5 border border-warm-gray"
              >
                <span className="font-mono-custom text-xs text-slate_blue">
                  MBA
                </span>
              </motion.div>
              <motion.div
                animate={{ y: [5, -5, 5] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-2 left-4 bg-white rounded-lg shadow-card px-3 py-1.5 border border-warm-gray"
              >
                <span className="font-mono-custom text-xs text-sienna">
                  SRM
                </span>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="flex flex-col items-center gap-2 text-charcoal/40"
          >
            <span className="font-mono-custom text-xs">scroll</span>
            <ArrowDown size={16} />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
