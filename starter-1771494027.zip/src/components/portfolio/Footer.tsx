const Footer = () => {
  return (
    <footer className="py-12 border-t border-warm-gray/50">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-display text-lg font-bold text-charcoal">
              Udhayakumar
            </span>
            <span className="font-mono-custom text-xs text-charcoal/40">
              © {new Date().getFullYear()}
            </span>
          </div>

          <p className="font-body text-sm text-charcoal/50 text-center">
            MBA Graduate · SRM University · Business Analysis & Digital Marketing
          </p>

          <div className="flex items-center gap-1">
            <span className="font-mono-custom text-xs text-charcoal/30">
              Built with
            </span>
            <span className="text-sienna text-sm">♦</span>
            <span className="font-mono-custom text-xs text-charcoal/30">
              analytical precision
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
