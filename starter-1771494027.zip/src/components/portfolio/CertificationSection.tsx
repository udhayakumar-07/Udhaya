import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Award, CheckCircle, ExternalLink } from "lucide-react";

const CertificationSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="certification" className="py-24 md:py-32" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.4, 0.0, 0.2, 1] }}
          className="mb-12"
        >
          <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
            Credentials
          </span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-charcoal mt-3">
            Certifications
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.4, 0.0, 0.2, 1] }}
          className="max-w-2xl"
        >
          {/* Certification Card */}
          <div className="relative bg-white rounded-xl border border-warm-gray shadow-card p-8 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 overflow-hidden">
            {/* Premium gradient accent */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-sienna via-sienna-light to-slate_blue" />
            
            {/* Badge Icon */}
            <div className="flex items-start gap-5">
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-sienna/15 to-sienna/5 flex items-center justify-center flex-shrink-0 border border-sienna/10">
                <Award className="w-8 h-8 text-sienna" />
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="font-mono-custom text-xs text-green-600 font-medium uppercase tracking-wider">
                    Verified
                  </span>
                </div>
                
                <h3 className="font-heading text-xl font-semibold text-charcoal mb-1">
                  Digital Marketing Certification
                </h3>
                
                <p className="font-body text-charcoal/60 mb-4">
                  Comprehensive digital marketing program covering SEO, SEM, social media marketing, content strategy, analytics, and campaign optimization.
                </p>

                <div className="flex flex-wrap items-center gap-4 mb-5">
                  <div className="flex items-center gap-2">
                    <span className="font-body text-sm text-charcoal/50">Issued by</span>
                    <span className="font-heading text-sm font-semibold text-charcoal">
                      Programming Hub
                    </span>
                  </div>
                  <div className="h-4 w-px bg-warm-gray" />
                  <div className="flex items-center gap-2">
                    <span className="font-body text-sm text-charcoal/50">Completed</span>
                    <span className="font-mono-custom text-sm font-medium text-charcoal">
                      2025
                    </span>
                  </div>
                </div>

                {/* Skills from certification */}
                <div className="flex flex-wrap gap-2">
                  {["SEO", "SEM", "Social Media", "Content Strategy", "Analytics"].map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-slate_blue/8 text-slate_blue text-xs font-heading font-medium rounded-md border border-slate_blue/10"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CertificationSection;
