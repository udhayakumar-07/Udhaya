import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { BarChart3, TrendingUp, Database, ChevronRight, X, IndianRupee } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const gstData = [
  { state: "Maharashtra", revenue: 45023, color: "#C17F4A" },
  { state: "Karnataka", revenue: 31245, color: "#3A5A6B" },
  { state: "Gujarat", revenue: 28567, color: "#C17F4A" },
  { state: "Tamil Nadu", revenue: 26890, color: "#3A5A6B" },
  { state: "Uttar Pradesh", revenue: 22345, color: "#C17F4A" },
  { state: "Delhi", revenue: 19876, color: "#3A5A6B" },
  { state: "Telangana", revenue: 18432, color: "#C17F4A" },
  { state: "West Bengal", revenue: 14567, color: "#3A5A6B" },
  { state: "Rajasthan", revenue: 12890, color: "#C17F4A" },
  { state: "Haryana", revenue: 11234, color: "#3A5A6B" },
];

const keyInsights = [
  "Maharashtra consistently leads GST revenue collection, contributing over 20% of national total",
  "Southern states show strong industrial and services sector contribution",
  "Year-over-year growth indicates expanding formal economy participation",
  "State-wise disparities highlight regional economic development patterns",
];

const ProjectSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeBar, setActiveBar] = useState<number | null>(null);

  return (
    <section id="project" className="py-24 md:py-32" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.4, 0.0, 0.2, 1] }}
          className="mb-12"
        >
          <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
            Featured Project
          </span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-charcoal mt-3">
            GST Revenue Analysis
          </h2>
        </motion.div>

        {/* Project Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.4, 0.0, 0.2, 1] }}
        >
          <div
            className="bg-gradient-to-br from-cream to-warm-cream rounded-xl border border-warm-gray shadow-card overflow-hidden hover:shadow-card-hover transition-all duration-200 cursor-pointer"
            onClick={() => !isExpanded && setIsExpanded(true)}
          >
            {/* Card Header */}
            <div className="p-8 md:p-10">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Info */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-sienna/10 flex items-center justify-center">
                      <IndianRupee className="w-5 h-5 text-sienna" />
                    </div>
                    <h3 className="font-heading text-xl font-semibold text-charcoal">
                      India's State-wise GST Revenue Collection
                    </h3>
                  </div>

                  <p className="font-body text-charcoal/70 leading-relaxed">
                    A comprehensive analysis of India's Goods and Services Tax revenue across all states, examining collection patterns, growth trends, and regional economic indicators to understand fiscal health and policy impact.
                  </p>

                  {/* Quick metrics */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-white/70 rounded-lg p-3 border border-warm-gray/50">
                      <p className="font-mono-custom text-xs text-charcoal/50 mb-1">States Analyzed</p>
                      <p className="font-mono-custom text-lg font-medium text-charcoal">28+</p>
                    </div>
                    <div className="bg-white/70 rounded-lg p-3 border border-warm-gray/50">
                      <p className="font-mono-custom text-xs text-charcoal/50 mb-1">Data Points</p>
                      <p className="font-mono-custom text-lg font-medium text-charcoal">500+</p>
                    </div>
                    <div className="bg-white/70 rounded-lg p-3 border border-warm-gray/50">
                      <p className="font-mono-custom text-xs text-charcoal/50 mb-1">Key Insights</p>
                      <p className="font-mono-custom text-lg font-medium text-sienna">12</p>
                    </div>
                  </div>

                  {!isExpanded && (
                    <button
                      className="inline-flex items-center gap-2 text-sienna font-heading font-semibold text-sm hover:gap-3 transition-all duration-200"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsExpanded(true);
                      }}
                    >
                      Explore Full Analysis
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Right: Chart Preview */}
                <div className="bg-white/80 rounded-xl p-4 border border-warm-gray/50">
                  <p className="font-heading text-sm font-semibold text-charcoal/70 mb-3">
                    Top 10 States by GST Revenue (₹ Cr.)
                  </p>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={gstData}
                        margin={{ top: 5, right: 10, left: -10, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" />
                        <XAxis
                          dataKey="state"
                          tick={{ fontSize: 10, fontFamily: "JetBrains Mono", fill: "#2B2B2B80" }}
                          angle={-45}
                          textAnchor="end"
                          height={60}
                        />
                        <YAxis
                          tick={{ fontSize: 10, fontFamily: "JetBrains Mono", fill: "#2B2B2B80" }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#2B2B2B",
                            border: "none",
                            borderRadius: "8px",
                            color: "#F8F6F1",
                            fontFamily: "JetBrains Mono",
                            fontSize: "12px",
                          }}
                          formatter={(value: number) => [`₹${value.toLocaleString()} Cr.`, "Revenue"]}
                        />
                        <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
                          {gstData.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={activeBar === index ? "#C17F4A" : entry.color}
                              opacity={activeBar === null || activeBar === index ? 1 : 0.5}
                              onMouseEnter={() => setActiveBar(index)}
                              onMouseLeave={() => setActiveBar(null)}
                              style={{ cursor: "pointer", transition: "opacity 0.2s" }}
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>

            {/* Expanded Content */}
            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.5, ease: [0.4, 0.0, 0.2, 1] }}
                  className="overflow-hidden"
                >
                  <div className="border-t border-warm-gray/50 p-8 md:p-10 space-y-8">
                    {/* Close button */}
                    <div className="flex justify-end">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsExpanded(false);
                        }}
                        className="p-2 rounded-lg hover:bg-warm-gray/50 transition-colors duration-200"
                      >
                        <X className="w-5 h-5 text-charcoal/60" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Methodology */}
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <Database className="w-5 h-5 text-slate_blue" />
                          <h4 className="font-heading text-lg font-semibold text-charcoal">
                            Methodology
                          </h4>
                        </div>
                        <ul className="space-y-3 font-body text-charcoal/70">
                          <li className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-sienna mt-2 flex-shrink-0" />
                            Collected GST revenue data from official government portals and financial databases
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-sienna mt-2 flex-shrink-0" />
                            Applied statistical analysis for state-wise comparison and trend identification
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-sienna mt-2 flex-shrink-0" />
                            Created visual dashboards for clear representation of revenue patterns
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-sienna mt-2 flex-shrink-0" />
                            Cross-referenced with GDP data to analyze economic correlation
                          </li>
                        </ul>
                      </div>

                      {/* Key Insights */}
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <TrendingUp className="w-5 h-5 text-sienna" />
                          <h4 className="font-heading text-lg font-semibold text-charcoal">
                            Key Findings
                          </h4>
                        </div>
                        <div className="space-y-3">
                          {keyInsights.map((insight, index) => (
                            <motion.div
                              key={index}
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{
                                delay: 0.1 + index * 0.1,
                                duration: 0.4,
                                ease: [0.4, 0.0, 0.2, 1],
                              }}
                              className="flex items-start gap-3 bg-white/60 rounded-lg p-3 border border-warm-gray/30"
                            >
                              <span className="font-mono-custom text-xs text-sienna font-semibold mt-0.5">
                                {String(index + 1).padStart(2, "0")}
                              </span>
                              <p className="font-body text-sm text-charcoal/70">{insight}</p>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Data Sources */}
                    <div className="bg-white/60 rounded-lg p-5 border border-warm-gray/30">
                      <div className="flex items-center gap-2 mb-3">
                        <BarChart3 className="w-4 h-4 text-slate_blue" />
                        <h5 className="font-heading text-sm font-semibold text-charcoal">
                          Data Sources
                        </h5>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          "GST Council Reports",
                          "Ministry of Finance",
                          "CBIC Data Portal",
                          "State Revenue Departments",
                          "RBI Statistical Tables",
                        ].map((source) => (
                          <span
                            key={source}
                            className="px-3 py-1.5 bg-cream rounded-md font-mono-custom text-xs text-charcoal/60 border border-warm-gray/50"
                          >
                            {source}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ProjectSection;
