import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Mail, Phone, MapPin, Linkedin, ExternalLink } from "lucide-react";

const ContactSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="py-24 md:py-32" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.4, 0.0, 0.2, 1] }}
          className="mb-12"
        >
          <span className="font-mono-custom text-sm tracking-widest uppercase text-sienna">
            Let's Connect
          </span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-charcoal mt-3">
            Get in Touch
          </h2>
          <p className="font-body text-lg text-charcoal/60 mt-4 max-w-xl">
            I'm actively seeking opportunities in business analysis, marketing, and finance. Let's discuss how I can contribute to your organization.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Email Card */}
          <motion.a
            href="mailto:udhayakumar@email.com"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.4, 0.0, 0.2, 1] }}
            className="group bg-white rounded-xl border border-warm-gray shadow-card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-sienna/10 flex items-center justify-center group-hover:bg-sienna/20 transition-colors duration-200">
                <Mail className="w-5 h-5 text-sienna" />
              </div>
              <div>
                <p className="font-heading text-sm font-semibold text-charcoal group-hover:text-sienna transition-colors duration-200">
                  Email
                </p>
                <p className="font-mono-custom text-sm text-charcoal/60">
                  udhayakumar@email.com
                </p>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-1 text-sienna/0 group-hover:text-sienna transition-all duration-200">
              <span className="font-heading text-xs font-medium">Send Email</span>
              <ExternalLink className="w-3 h-3" />
            </div>
          </motion.a>

          {/* Phone Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.4, 0.0, 0.2, 1] }}
            className="group bg-white rounded-xl border border-warm-gray shadow-card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-slate_blue/10 flex items-center justify-center group-hover:bg-slate_blue/20 transition-colors duration-200">
                <Phone className="w-5 h-5 text-slate_blue" />
              </div>
              <div>
                <p className="font-heading text-sm font-semibold text-charcoal group-hover:text-slate_blue transition-colors duration-200">
                  Phone
                </p>
                <p className="font-mono-custom text-sm text-charcoal/60">
                  Available on request
                </p>
              </div>
            </div>
          </motion.div>

          {/* Location Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3, ease: [0.4, 0.0, 0.2, 1] }}
            className="group bg-white rounded-xl border border-warm-gray shadow-card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-sienna/10 flex items-center justify-center group-hover:bg-sienna/20 transition-colors duration-200">
                <MapPin className="w-5 h-5 text-sienna" />
              </div>
              <div>
                <p className="font-heading text-sm font-semibold text-charcoal group-hover:text-sienna transition-colors duration-200">
                  Location
                </p>
                <p className="font-mono-custom text-sm text-charcoal/60">
                  India
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Social Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4, ease: [0.4, 0.0, 0.2, 1] }}
          className="mt-10 flex items-center gap-4"
        >
          <span className="font-body text-sm text-charcoal/50">Connect on</span>
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-warm-gray shadow-sm hover:shadow-card hover:-translate-y-0.5 hover:border-slate_blue/30 transition-all duration-200"
          >
            <Linkedin className="w-4 h-4 text-slate_blue" />
            <span className="font-heading text-sm font-medium text-charcoal">
              LinkedIn
            </span>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactSection;
